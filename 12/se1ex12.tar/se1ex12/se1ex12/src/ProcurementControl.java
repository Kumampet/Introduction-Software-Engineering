package se1ex12.src;

/*
 * University of Aizu [Introduction to Software Engineering] Exercise material
 *
 * Class: ProcurementControl
 *
 * Date: 
 *
 * author: 
 *
 */
/*
 *
 * Complete the implementation of this class "ProcurementControl"
 *
 */
import java.sql.SQLException;
import java.util.Date;

public class ProcurementControl {
  // Declare necessary variables
  private Procurement procurement;
  private DBAccess dbAccess;

  public ProcurementControl() throws ClassNotFoundException, SQLException {
    // Initialization of DBAccess
    dbAccess = new DBAccess();
  }

  // Declare and implement necessary methods

}
